package com.zhenya.dpichanger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DpiChangerApp()
        }
    }
}

// Набор пресетов. Добавляй/меняй значения под свои часы.
private val DPI_PRESETS = listOf(160, 180, 200, 220, 240, 260, 280, 300, 320)

@Composable
fun DpiChangerApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var currentDpi by remember { mutableStateOf(DensityUtils.getCurrentDensity(context)) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    val listState = rememberScalingLazyListState()

    MaterialTheme {
        ScalingLazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                Text(
                    text = "Текущий DPI: $currentDpi",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            item {
                statusMessage?.let {
                    Text(
                        text = it,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.caption2
                    )
                }
            }

            items(DPI_PRESETS) { dpi ->
                Chip(
                    onClick = {
                        DensityUtils.setDensity(dpi).fold(
                            onSuccess = {
                                currentDpi = dpi
                                statusMessage = "Применено: $dpi"
                            },
                            onFailure = { e ->
                                statusMessage = e.message ?: "Ошибка"
                            }
                        )
                    },
                    label = { Text("$dpi dpi") },
                    colors = ChipDefaults.chipColors()
                )
            }

            item {
                Button(onClick = {
                    DensityUtils.resetDensity().fold(
                        onSuccess = {
                            currentDpi = DensityUtils.getDefaultDensity(context)
                            statusMessage = "Сброшено на заводское"
                        },
                        onFailure = { e ->
                            statusMessage = e.message ?: "Ошибка"
                        }
                    )
                }) {
                    Text("Сбросить")
                }
            }

            item {
                Text(
                    text = "Если ошибка прав — выполни на компьютере:\n" +
                            "adb shell pm grant com.zhenya.dpichanger " +
                            "android.permission.WRITE_SECURE_SETTINGS",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.caption3,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}
