package com.zhenya.dpichanger.xposed

import android.app.Application
import android.content.res.Configuration
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam

/**
 * Подменяет плотность экрана (densityDpi) ТОЛЬКО для указанного пакета,
 * не трогая системный DPI и остальные приложения.
 *
 * Требует: root + LSPosed framework, установленный и активированный на устройстве.
 * Без root и без LSPosed этот файл бесполезен — это ограничение платформы,
 * не приложения.
 *
 * Настрой TARGET_PACKAGES и TARGET_DENSITY под свои нужды и пересобери модуль,
 * либо вынеси конфиг в SharedPreferences и читай его здесь через
 * XSharedPreferences (стандартный паттерн для Xposed-модулей с настройками).
 */
class DensityHook : IXposedHookLoadPackage {

    // Список пакетов, для которых принудительно меняем плотность.
    // Например: "com.some.phoneonly.app"
    private val TARGET_PACKAGES = setOf(
        "com.example.targetapp"
    )

    // Желаемая плотность в dpi именно для этих приложений.
    // Меньшее значение -> UI компактнее -> больше шанс уместиться в квадрат/круг часов.
    private val TARGET_DENSITY = 160

    override fun handleLoadPackage(lpparam: LoadPackageParam) {
        if (lpparam.packageName !in TARGET_PACKAGES) return

        // Хук на Application.attach — самая ранняя надёжная точка,
        // где уже доступен Context для правки Configuration/Resources.
        XposedHelpers.findAndHookMethod(
            Application::class.java,
            "attach",
            android.content.Context::class.java,
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val app = param.thisObject as Application
                    overrideDensity(app)
                }
            }
        )
    }

    private fun overrideDensity(app: Application) {
        try {
            val resources = app.resources
            val config = Configuration(resources.configuration)
            config.densityDpi = TARGET_DENSITY

            @Suppress("DEPRECATION")
            resources.updateConfiguration(config, resources.displayMetrics)

            resources.displayMetrics.densityDpi = TARGET_DENSITY
            resources.displayMetrics.density = TARGET_DENSITY / 160f
        } catch (e: Throwable) {
            // Логируется в LSPosed Manager -> Logs
            de.robv.android.xposed.XposedBridge.log("DensityHook error: ${e.message}")
        }
    }
}
